#define ALGVORMINDUS
#define WCONS32
#define ET
#define CHCONVERT
