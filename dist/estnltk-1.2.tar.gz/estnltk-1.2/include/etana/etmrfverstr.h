#if !defined(ETMRFVERSTR_H)
#define ETMRFVERSTR_H
	extern const char *etMrfVersionString;
#endif
