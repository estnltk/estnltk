
#if !defined(LISAKR6NKSUD_H)
#define LISAKR6NKSUD_H
class LISAKR6NKSUD
    {
    public:
    LISAKR6NKSUD(void);

    char piir;              // liits�na osas�na piiri t�his
    char *lisaKr6nksudeStr; // k�igi lisakr�nksude string (sh liits�na osas�nade piir)
    };
#endif




