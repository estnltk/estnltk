//
// $Date: 2008-05-13 11:39:59 +0300 (T, 13 mai   2008) $ $Revision: 521 $
//
#ifndef SUURUSED_H
#define SUURUSED_H

	typedef unsigned char  UB1;
	typedef signed   char  SB1;

    typedef unsigned short UB2;
	typedef signed   short SB2;

    //typedef unsigned char  UB3[3];

    typedef unsigned int  UB4;
	typedef signed   int  SB4;

#endif



