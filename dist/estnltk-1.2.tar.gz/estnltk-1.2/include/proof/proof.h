#if !defined _PROOF_H_ajfhasdjsfh_
#define _PROOF_H_ajfhasdjsfh_

#include "etmrf.h"
#include "etmrfyhh.h"

#include "pttype.h"
#include "ptword.h"
#include "suggestor.h"
#include "linguistic.h"
#include "disambiguator.h"

#endif // _PROOF_H_ajfhasdjsfh_
