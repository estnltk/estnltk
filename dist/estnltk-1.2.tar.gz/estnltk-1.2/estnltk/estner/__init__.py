# -*- coding: utf-8 -*-

from estnltk.estner.crfsuiteutil import Trainer as CrfsuiteTrainer, Tagger as CrfsuiteTagger
from estnltk.estner.ner import Collection, Document, Sentence, Token
from estnltk.estner import settings
