# -*- coding: utf-8 -*-
"""Imports the tests from vabamorf package"""
from __future__ import unicode_literals, print_function, absolute_import

from ..vabamorf.tests.test_analyze import *
from ..vabamorf.tests.test_multi import *
from ..vabamorf.tests.test_synthesize import *

